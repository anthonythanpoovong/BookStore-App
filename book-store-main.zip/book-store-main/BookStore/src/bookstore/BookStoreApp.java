package bookstore;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

/**
 *
 * @author Jerome Magpantay
 */
public class BookStoreApp extends Application {
    
    private static Stage appStage;
    
    @Override
    public void start(Stage primaryStage) throws Exception{
        appStage = primaryStage;
        Parent root = FXMLLoader.load(getClass().getResource("LoginScene.fxml"));
        primaryStage.setTitle("Bookstore App");
        primaryStage.setScene(new Scene(root, 600, 400));
        primaryStage.show();
    }
    
    public void goToAdminStartScene() throws Exception{
        Parent admin = FXMLLoader.load(getClass().getResource("AdminStartScene.fxml"));
        appStage.getScene().setRoot(admin);
    }
    
    public void goToCustomerScene() throws Exception{
        Parent customer = FXMLLoader.load(getClass().getResource("CustomerScene.fxml"));
        appStage.getScene().setRoot(customer);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
