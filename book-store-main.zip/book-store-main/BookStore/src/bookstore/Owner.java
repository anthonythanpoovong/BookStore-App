package bookstore;

public class Owner {
    
    private Owner instance; 
    private String name; 
    private String password; 
    
    
    public Owner getInstance(){
        return instance; 
    }
        
    public String getName(){ 
        return name;
    }    
        
    public String getPassword(){ 
        return password;
    }
    
    
    
}
