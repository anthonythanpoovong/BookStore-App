/*
 * Customer Class
 * COE528 
 */
package bookstore;

import javafx.scene.control.CheckBox;

public class Customer {
    private String status;
    private String name;
    private String username;
    private int points;
    private String password;
    private CheckBox select;
    
    public Customer(String status, String name, String username, int points, String password) {
        this.status = status;
        this.name = name;
        this.username = username;
        this.points = points;
        this.password = password;
    }
    
    //Getters and Setters
    public String getStatus () {
        if (points < 1000) {
            status = "Silver";
        }
        else {
            status = "Gold";
        }
        return status;
    }

    public String getName() {
        return name;
    }
    
    public String getUsername() {
        return username;
    }

    public int getPoints() {
        return points;
    }

    public String getPassword() {
        return password;
    }
    
    public CheckBox getSelect(){
        return select;
    }
    
    public void setSelect(CheckBox select) {
        this.select=select;
    }

    public void setPoints (int points) {
        this.points = points;
    }
}
