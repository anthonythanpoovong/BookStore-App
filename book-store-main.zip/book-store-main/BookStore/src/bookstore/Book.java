package bookstore;

/**
 *
 * @author Caleb Lam
 */
public class Book {

    private double price;
    private String title;

    public Book(String title, double price) {
        this.title = title;
        this.price = price;
    }

    public double getPrice() {
        return this.price;
    }

    public String getTitle() {
        return this.title;
    }

}
