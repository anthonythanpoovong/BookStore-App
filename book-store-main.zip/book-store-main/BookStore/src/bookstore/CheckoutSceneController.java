/*
 * COE528
 * CheckoutSceneController
 * and open the template in the editor.
 */
package bookstore;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author thanp
 */
public class CheckoutSceneController  {

    @FXML
    private Label showCost;
    @FXML
    private Label showPoints;
    @FXML
    private Label showStatus;
    @FXML
    private Button logout;
    
    private Customer customer;
    
    public CheckoutSceneController () {
    
    //Still working on this
    //Still unsure how we will calculate the cost for each customer
    //showCost.setText(String.format("$%.2f", customer.getCost));
        
    //Returns both Points and Status of the customer
    showPoints.setText(String.format("%d", customer.getPoints()));
    showPoints.setText(customer.getStatus());
    }
    
    @FXML
    public void logoutButton (ActionEvent event) throws Exception {
        //Logout button function
    }
}
