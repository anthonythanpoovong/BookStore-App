package bookstore;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

/**
 *
 * @author Caleb Lam
 */
public class DataStore {
    private static DataStore instance = null;
    private static final String customersFilePath = "customers.txt";
    private static final String booksFilePath = "books.txt";
    
    private HashMap<String, Customer> customers = new HashMap<>();
    private ArrayList<Book> books = new ArrayList<>();
    
    private DataStore() {
        
    }
    
    public void loadData() {
        try {
            // Write the code here
            File customersFile = new File(customersFilePath);
            
            try (Scanner reader = new Scanner(customersFile)) {
                while (reader.hasNextLine()) {
                    String username = reader.nextLine();
                    String password = reader.nextLine();
                    String name = reader.nextLine();
                    int points = reader.nextInt();
                    String status = reader.nextLine();
                    
                    Customer c = new Customer(status, name, username, points, password);
                    customers.put(username, c);
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while loading customers: " + e.getMessage());
        }
        
        try {
            // Write the code here
            File booksFile = new File(booksFilePath);
            
            try (Scanner reader = new Scanner(booksFile)) {
                while (reader.hasNextLine()) {
                    String title = reader.nextLine();
                    double price = reader.nextDouble();
                    
                    Book b = new Book(title, price);
                    books.add(b);
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while loading books: " + e.getMessage());
        }
    }
    
    public void saveData() {
        try {
            // Write the code here
            File customersFile = new File(customersFilePath);
            
            try (FileWriter writer = new FileWriter(customersFile, false)) {
                for (Customer c : customers.values()) {
                    writer.write(c.getUsername());
                    writer.write(c.getPassword());
                    writer.write(c.getName());
                    writer.write(c.getPoints());
                    writer.write(c.getStatus());
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while saving customers: " + e.getMessage());
        }
        
        try {
            // Write the code here
            File booksFile = new File(booksFilePath);
            
            try (FileWriter writer = new FileWriter(booksFile, false)) {
                for (Book b : books) {
                    writer.write(b.getTitle());
                    writer.write(Double.toString(b.getPrice()));
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while saving books: " + e.getMessage());
        }
    }
    
    public Customer getCustomer(String username) {
        if (customers.containsKey(username)) {
            return customers.get(username);
        } else {
            return null;
        }
    }
    
    public ArrayList<Book> getBooks() {
        return (ArrayList<Book>)books.clone();
    }
    
    public static DataStore getInstance() {
        if (instance == null) {
            instance = new DataStore();
        }
        
        return instance;
    }
}
