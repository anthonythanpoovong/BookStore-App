/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstore;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;

public class BookStorePurchaseSceneController {

    @FXML
    private TableColumn<Customer, String> bookName;

    //How to link price of book into the column
    //@FXML
    //private TableColumn <CustomerClass, double> bookPrice;
    @FXML
    private TableColumn<Customer, CheckBox> select;
    @FXML
    private Button buy;

    @FXML
    private void buyButton(ActionEvent event) throws IOException {
        System.out.println("You clicked me!");
        //Parent purchaseParent = FXMLLoader.load(getClass().getResource("CheckoutScene.fxml"));
        //Scene purchaseScene = new Scene(purchaseParent);

        //Here I want to swap the screen!
        //Stage purchaseStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        // OR
        //purchaseStage.setScene(purchaseScene);
        // purchaseStage.show();
        // these two of them return the same stage
        // Swap screen
    }
    @FXML
    private Button redeemPoints;
    @FXML
    private Button logout;
}
