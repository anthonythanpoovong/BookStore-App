package bookstore;

import java.util.HashMap;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.fxml.Initializable;

/**
 *
 * @author Jerome Magpantay
 */
public class LoginController {
    
    @FXML
    private Button loginButton;
    @FXML
    private TextField usernameInput; 
    @FXML
    private PasswordField passwordInput;
    @FXML
    private Label errorMessage;
    private HashMap<String, String> customerLogin = new HashMap<>();
    
    //Adding usernames and passwords to hashmap.
    public LoginController(){
        customerLogin.put("Jerome", "1234");
    }

   //Checks for admin login, if not passes it to check user login.
   public void checkAdminLogin() throws Exception{
        BookStoreApp adminView = new BookStoreApp();
        if(usernameInput.getText().equals("admin") && passwordInput.getText().equals("admin")){
            adminView.goToAdminStartScene();
        }else{
            checkUserLogin();
        }
    }
   
   
   //Login button function.
   @FXML
   public void loginAttempt(ActionEvent event) throws Exception{
       checkAdminLogin();
   }
   
   //Checks for customer login by checking if username is in hashmap, and if password elements match.
    public void checkUserLogin() throws Exception{
        BookStoreApp customerView = new BookStoreApp();
        if(customerLogin.containsKey(usernameInput.getText()) && passwordInput.getText().equals(customerLogin.get(usernameInput.getText()))){
            customerView.goToCustomerScene();
        }else{
            errorMessage.setText("Incorrect Username/Password, Try Again");
        }
    }
}
